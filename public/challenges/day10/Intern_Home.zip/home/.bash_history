ls
nano .secret
cat .secret
exit
