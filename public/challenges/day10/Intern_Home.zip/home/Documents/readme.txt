NovaTech intern notes — nothing sensitive here.
