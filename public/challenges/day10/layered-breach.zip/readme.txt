Join the two stage labels in order, then finish with the live desk suffix.
