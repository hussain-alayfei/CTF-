Workstation triage — correlate session, downloads, and visits.
