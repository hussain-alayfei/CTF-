DEEP BREACH KIT
===============
Two stages. Use any tools you like (browser or desktop).

STAGE 1 — recover the key material
  stage1.b64 is Base64. Decode it (CyberChef 'From Base64', or
  `base64 -d`) to reveal the AES-256-CBC KEY and IV (both hex).

STAGE 2 — decrypt the payload
  payload.enc.hex is the ciphertext as hex. Decrypt with AES-256-CBC.

  CyberChef:  From Hex -> AES Decrypt (Key HEX, IV HEX, mode CBC, input Raw)
  openssl:    xxd -r -p payload.enc.hex | \
                openssl enc -d -aes-256-cbc -nosalt -K <KEY> -iv <IV>

The plaintext is the flag.
