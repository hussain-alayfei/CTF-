DEEP BREACH KIT
===============
This challenge's live page (open it from the arena) hands you the key
material for this session -- it is deliberately not included here.

payload.enc.hex is the locked payload, as hex. Recover the plaintext.
